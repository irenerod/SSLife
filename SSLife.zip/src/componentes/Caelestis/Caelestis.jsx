import React from "react";
import './Caelestis.css';

const Caelestis = () => {
  return (
    <section className="contenedorCaelestis">
    <section className="caelestis">
      <div className="uno"></div>
      <p></p>
      <div className="tres"></div>
    </section>
    </section>
  );
};

export default Caelestis;
